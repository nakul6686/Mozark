export const data =[
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 32,
    "humidity": 75,
    "population": 4000000,
    "date": "2024-07-01"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 30,
    "humidity": 85,
    "population": 20000000,
    "date": "2024-07-01"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 40,
    "humidity": 50,
    "population": 19000000,
    "date": "2024-07-01"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 34,
    "humidity": 80,
    "population": 10000000,
    "date": "2024-07-01"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 35,
    "humidity": 72,
    "population": 4000000,
    "date": "2024-07-02"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 31,
    "humidity": 84,
    "population": 20000000,
    "date": "2024-07-02"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 39,
    "humidity": 52,
    "population": 19000000,
    "date": "2024-07-02"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 33,
    "humidity": 81,
    "population": 10000000,
    "date": "2024-07-02"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 33,
    "humidity": 70,
    "population": 4000000,
    "date": "2024-07-03"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 32,
    "humidity": 83,
    "population": 20000000,
    "date": "2024-07-03"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 38,
    "humidity": 53,
    "population": 19000000,
    "date": "2024-07-03"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 34,
    "humidity": 80,
    "population": 10000000,
    "date": "2024-07-03"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 34,
    "humidity": 68,
    "population": 4000000,
    "date": "2024-07-04"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 33,
    "humidity": 82,
    "population": 20000000,
    "date": "2024-07-04"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 37,
    "humidity": 54,
    "population": 19000000,
    "date": "2024-07-04"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 35,
    "humidity": 79,
    "population": 10000000,
    "date": "2024-07-04"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 31,
    "humidity": 65,
    "population": 4000000,
    "date": "2024-07-05"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 30,
    "humidity": 81,
    "population": 20000000,
    "date": "2024-07-05"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 36,
    "humidity": 55,
    "population": 19000000,
    "date": "2024-07-05"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 36,
    "humidity": 78,
    "population": 10000000,
    "date": "2024-07-05"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 30,
    "humidity": 63,
    "population": 4000000,
    "date": "2024-07-06"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 31,
    "humidity": 80,
    "population": 20000000,
    "date": "2024-07-06"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 35,
    "humidity": 56,
    "population": 19000000,
    "date": "2024-07-06"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 35,
    "humidity": 77,
    "population": 10000000,
    "date": "2024-07-06"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 29,
    "humidity": 62,
    "population": 4000000,
    "date": "2024-07-07"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 32,
    "humidity": 79,
    "population": 20000000,
    "date": "2024-07-07"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 34,
    "humidity": 57,
    "population": 19000000,
    "date": "2024-07-07"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 36,
    "humidity": 76,
    "population": 10000000,
    "date": "2024-07-07"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 28,
    "humidity": 60,
    "population": 4000000,
    "date": "2024-07-08"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 33,
    "humidity": 78,
    "population": 20000000,
    "date": "2024-07-08"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 33,
    "humidity": 58,
    "population": 19000000,
    "date": "2024-07-08"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 34,
    "humidity": 75,
    "population": 10000000,
    "date": "2024-07-08"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 27,
    "humidity": 58,
    "population": 4000000,
    "date": "2024-07-09"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 34,
    "humidity": 77,
    "population": 20000000,
    "date": "2024-07-09"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 32,
    "humidity": 59,
    "population": 19000000,
    "date": "2024-07-09"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 33,
    "humidity": 74,
    "population": 10000000,
    "date": "2024-07-09"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 26,
    "humidity": 56,
    "population": 4000000,
    "date": "2024-07-10"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 35,
    "humidity": 76,
    "population": 20000000,
    "date": "2024-07-10"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 31,
    "humidity": 60,
    "population": 19000000,
    "date": "2024-07-10"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 32,
    "humidity": 73,
    "population": 10000000,
    "date": "2024-07-10"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 25,
    "humidity": 55,
    "population": 4000000,
    "date": "2024-07-11"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 34,
    "humidity": 75,
    "population": 20000000,
    "date": "2024-07-11"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 30,
    "humidity": 61,
    "population": 19000000,
    "date": "2024-07-11"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 31,
    "humidity": 72,
    "population": 10000000,
    "date": "2024-07-11"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 24,
    "humidity": 53,
    "population": 4000000,
    "date": "2024-07-12"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 33,
    "humidity": 74,
    "population": 20000000,
    "date": "2024-07-12"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 29,
    "humidity": 62,
    "population": 19000000,
    "date": "2024-07-12"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 30,
    "humidity": 71,
    "population": 10000000,
    "date": "2024-07-12"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 23,
    "humidity": 50,
    "population": 4000000,
    "date": "2024-07-13"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 32,
    "humidity": 73,
    "population": 20000000,
    "date": "2024-07-13"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 28,
    "humidity": 63,
    "population": 19000000,
    "date": "2024-07-13"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 29,
    "humidity": 70,
    "population": 10000000,
    "date": "2024-07-13"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 22,
    "humidity": 48,
    "population": 4000000,
    "date": "2024-07-14"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 31,
    "humidity": 72,
    "population": 20000000,
    "date": "2024-07-14"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 27,
    "humidity": 64,
    "population": 19000000,
    "date": "2024-07-14"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 28,
    "humidity": 69,
    "population": 10000000,
    "date": "2024-07-14"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 21,
    "humidity": 46,
    "population": 4000000,
    "date": "2024-07-15"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 30,
    "humidity": 71,
    "population": 20000000,
    "date": "2024-07-15"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 26,
    "humidity": 65,
    "population": 19000000,
    "date": "2024-07-15"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 27,
    "humidity": 68,
    "population": 10000000,
    "date": "2024-07-15"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 20,
    "humidity": 44,
    "population": 4000000,
    "date": "2024-07-16"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 29,
    "humidity": 70,
    "population": 20000000,
    "date": "2024-07-16"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 25,
    "humidity": 66,
    "population": 19000000,
    "date": "2024-07-16"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 26,
    "humidity": 67,
    "population": 10000000,
    "date": "2024-07-16"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 19,
    "humidity": 42,
    "population": 4000000,
    "date": "2024-07-17"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 28,
    "humidity": 69,
    "population": 20000000,
    "date": "2024-07-17"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 24,
    "humidity": 67,
    "population": 19000000,
    "date": "2024-07-17"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 25,
    "humidity": 66,
    "population": 10000000,
    "date": "2024-07-17"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 18,
    "humidity": 40,
    "population": 4000000,
    "date": "2024-07-18"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 27,
    "humidity": 68,
    "population": 20000000,
    "date": "2024-07-18"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 23,
    "humidity": 68,
    "population": 19000000,
    "date": "2024-07-18"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 24,
    "humidity": 65,
    "population": 10000000,
    "date": "2024-07-18"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 17,
    "humidity": 38,
    "population": 4000000,
    "date": "2024-07-19"
  },
  {
    "country": "India",


    "city": "Mumbai",
    "temprature": 26,
    "humidity": 67,
    "population": 20000000,
    "date": "2024-07-19"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 22,
    "humidity": 69,
    "population": 19000000,
    "date": "2024-07-19"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 23,
    "humidity": 64,
    "population": 10000000,
    "date": "2024-07-19"
  },
  {
    "country": "India",
    "city": "Bangalore",
    "temprature": 16,
    "humidity": 36,
    "population": 4000000,
    "date": "2024-07-20"
  },
  {
    "country": "India",
    "city": "Mumbai",
    "temprature": 25,
    "humidity": 66,
    "population": 20000000,
    "date": "2024-07-20"
  },
  {
    "country": "India",
    "city": "Delhi",
    "temprature": 21,
    "humidity": 70,
    "population": 19000000,
    "date": "2024-07-20"
  },
  {
    "country": "India",
    "city": "Chennai",
    "temprature": 22,
    "humidity": 63,
    "population": 10000000,
    "date": "2024-07-20"
  }
]
