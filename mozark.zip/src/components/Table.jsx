import React, { useState } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Tag } from "primereact/tag";

const Table = ({ data }) => {
  const [tableData, setTableData] = useState(data);
  const [expandedRows, setExpandedRows] = useState([]);

  const headerTemplate = (data) => {
    return (
      <React.Fragment>
        <span className="vertical-align-middle ml-2 fw-bold line-height-3">
          {data.city}
        </span>
      </React.Fragment>
    );
  };


  const countryBodyTemplate = (rowData) => {
    return (
      <div className="flex align-items-center gap-2">
        <img
          alt={rowData.country}
          src="https://primefaces.org/cdn/primereact/images/flag/flag_placeholder.png"
          className={`flag flag-${rowData.country.code}`}
          style={{ width: "24px" }}
        />
        <span>{rowData.country}</span>
      </div>
    );
  };

  function formatDate(rowData) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    const date = new Date(rowData.date);
    const day = String(date.getDate()).padStart(2, "0");
    const month = months[date.getMonth()];
    const year = date.getFullYear();

    return <Tag severity="info" value={`${day} ${month} ${year}`}></Tag>;
  }

  const tempratureTemplate = (rowdata, hum) => {
    return (
      <span
        style={{
          background: "#f97316",
          padding: "3px 5px",
          color: "#FFF",
          borderRadius: "2px",
        }}
      >
        {" "}
        {rowdata.temprature}&deg;C
      </span>
    );
  };
  const humidityTemplate = (rowdata) => {
    return (
      <span
        style={{
          background: "#06b6d4",
          padding: "3px 5px",
          color: "#FFF",
          borderRadius: "2px",
        }}
      >
        {" "}
        {rowdata.humidity}&deg;C
      </span>
    );
  };

  return (
    <div className="card">
      <DataTable
        value={tableData}
        rowGroupMode="subheader"
        groupRowsBy="city"
        sortMode="single"
        sortField="city"
        sortOrder={1}
        expandableRowGroups
        expandedRows={expandedRows}
        onRowToggle={(e) => setExpandedRows(e.data)}
        rowGroupHeaderTemplate={headerTemplate}
        tableStyle={{ minWidth: "50rem" }}
        stripedRows
        paginator
        rows={60}
        rowsPerPageOptions={[60, 80, 100, 150]}
      >
        <Column field="city" header="City"></Column>
        <Column
          field="country"
          header="Country"
          body={countryBodyTemplate}
        ></Column>
        <Column
          field="temprature"
          header="Temprature"
          body={tempratureTemplate}
          sortable
        ></Column>
        <Column
          field="humidity"
          header="Humidity"
          body={humidityTemplate}
          sortable
        ></Column>
        <Column field="population" header="Population" sortable></Column>
        <Column
          field="date"
          header="Date"
          style={{ width: "20%" }}
          body={formatDate}
          sortable
        ></Column>
      </DataTable>
    </div>
  );
};
export default Table;
