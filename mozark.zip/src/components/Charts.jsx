import React, { useEffect, useState } from "react";
import { Chart } from "primereact/chart";
import { Dropdown } from "primereact/dropdown";

const options = {
  maintainAspectRatio: false,
  aspectRatio: 0.6,
  plugins: {
    legend: {
      labels: {
        color: "#4b5563",
      },
    },
  },
  scales: {
    x: {
      ticks: {
        color: "#4b5563",
      },
      grid: {
        color: "transparent",
      },
    },
    y: {
      ticks: {
        color: "#4b5563",
      },
      grid: {
        color: "#e7e9ed",
      },
    },
  },
};

function Charts({ data }) {
  let [groupedData, setGroupedData] = useState(null);
  const [chartData, setChartData] = useState({});
  const [chartOptions, setChartOptions] = useState(options);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(null);

  useEffect(() => {
    groupDataByCities();
  }, []);

  useEffect(() => {
    createDynamicChart();
  }, [data, groupedData, selectedCity]);

  function groupDataByCities() {
    let result = data.reduce((acc, element) => {
      if (element.city in acc) {
        acc[element.city].push(element);
      } else {
        acc[element.city] = new Array(element);
      }
      return acc;
    }, {});
    setGroupedData(result);
    let dataCities = Object.keys(result);
    setCities((prev) => {
      let res = dataCities.map((city) => ({ name: city, code: city }));
      return res;
    });
    if (!selectedCity) {
      setSelectedCity({name:dataCities[0], code:dataCities[0]});
    }
  }

  function createDynamicChart() {
    if (groupedData && selectedCity) {
      const viewData = {
        labels: [],
        datasets: [],
      };
      viewData.labels = groupedData[selectedCity.name].map((item) => item.date);
      let temprature = {
        type: "line",
        label: "Temprature",
        borderColor: "#3b82f6", //documentStyle.getPropertyValue('--blue-500'),
        borderWidth: 2,
        fill: false,
        tension: 0.4,
        data: groupedData[selectedCity.name].map(
          (item) => item.temprature
        ),
      };
      let humidityData = {
        type: "bar",
        label: "Humidity",
        backgroundColor: "#ec4899", //documentStyle.getPropertyValue('--orange-500'),
        data: groupedData[selectedCity.name].map(
          (item) => item.humidity
        ),
      };
      viewData.datasets = [temprature, humidityData];
      setChartData(viewData);
    }
  }

  return (
    <div>
      <div className="d-flex">
        <Dropdown
          value={selectedCity}
          onChange={(e) => setSelectedCity(e.value)}
          options={cities}
          optionLabel="name"
          placeholder="Select a City"
          className="w-full md:w-14rem"
        />
      </div>
      <Chart type="line" data={chartData} options={chartOptions} />
    </div>
  );
}

export default Charts;
