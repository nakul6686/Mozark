import React, { useEffect, useState } from "react";
import { data } from "./data";
import { TabView, TabPanel } from "primereact/tabview";
import Table from "./components/Table";
import Charts from "./components/Charts";
import "./App.css"


function App() {

  return (
    <div className="container mt-3">
      <div className="row">
        <div className="col-sm-12">
          <div className="card">
            <TabView>
              <TabPanel header="Tabular">
                <Table data={data}/>
              </TabPanel>
              <TabPanel header="Charts">
                <Charts data={data}/>
              </TabPanel>
            </TabView>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
